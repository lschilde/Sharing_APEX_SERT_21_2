PROMPT == SV_SEC_COLORS

CREATE TABLE sv_sec_colors
  (
  id                         NUMBER,
  r                          NUMBER NOT NULL, 
  g                          NUMBER NOT NULL,
  b                          NUMBER NOT NULL
 )
/