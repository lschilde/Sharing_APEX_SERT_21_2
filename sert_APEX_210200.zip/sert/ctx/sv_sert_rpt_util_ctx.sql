set concat off
CREATE OR REPLACE CONTEXT sv_sert_rpt_util_ctx USING ^esert_user.sv_sec_rpt_util
/
set concat on