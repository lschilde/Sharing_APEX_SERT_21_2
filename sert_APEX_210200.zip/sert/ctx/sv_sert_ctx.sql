set concat off 
CREATE OR REPLACE CONTEXT sv_sert_ctx USING ^esert_user.sv_sec_util
/
set concat on 